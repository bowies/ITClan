package spring.model.subsurvey;

public class SubSurveyDTO {

	private int ans1;
	private int ans2;
	private int ans3;
	private int ans4;
	private int preNum;
	
	
	
	
	
	public int getAns1() {
		return ans1;
	}
	public void setAns1(int ans1) {
		this.ans1 = ans1;
	}
	public int getAns2() {
		return ans2;
	}
	public void setAns2(int ans2) {
		this.ans2 = ans2;
	}
	public int getAns3() {
		return ans3;
	}
	public void setAns3(int ans3) {
		this.ans3 = ans3;
	}
	public int getAns4() {
		return ans4;
	}
	public void setAns4(int ans4) {
		this.ans4 = ans4;
	}

	public int getPreNum() {
		return preNum;
	}
	public void setPreNum(int preNum) {
		this.preNum = preNum;
	}
	
	
	
}
